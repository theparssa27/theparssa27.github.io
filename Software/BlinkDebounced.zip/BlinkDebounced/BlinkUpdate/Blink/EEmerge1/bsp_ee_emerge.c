#include "bsp_ee_emerge.h"

#include <msp430.h>
#include "ws2812.h"
#include "pins_energia.h"
#include "Energia.h"
#include <stdint.h>

#define BUTTON1 (P2_3)
#define BUTTON2 (P2_5)
#define BUTTON3 (P2_6)
#define BUTTON4 (P2_7)

#define DIAL1 (P1_0)
#define DIAL2 (P1_3)



static Init_Buttons(void);
static Init_Dials(void);
static Init_Neopixels(void);

static uint8_t ledBrightness = 0;
static uint8_t ledSpeed      = 0;

void BSP_Init(void)
{
    Init_Buttons();
    Init_Dials();
    Init_Neopixels();
}

uint8_t Button1_Get(void)
{
    volatile int out = ((uint8_t) digitalRead(BUTTON1));
    return out;
}
uint8_t Button2_Get(void)
{
    return ((uint8_t) digitalRead(BUTTON2));
}
uint8_t Button3_Get(void)
{
    return ((uint8_t) digitalRead(BUTTON3));
}
uint8_t Button4_Get(void)
{
    return ((uint8_t) digitalRead(BUTTON4));
}

uint16_t Dial1_Get(void)
{
    return ((uint16_t) analogRead(DIAL1));
}

uint16_t Dial2_Get(void)
{
    return ((uint16_t) analogRead(DIAL2));
}

static Init_Buttons(void)
{
    pinMode(BUTTON1, INPUT_PULLUP);
    pinMode(BUTTON2, INPUT_PULLUP);
    pinMode(BUTTON3, INPUT_PULLUP);
    pinMode(BUTTON4, INPUT_PULLUP);
}

static Init_Dials(void)
{
    // Setting up an analog dial requires nothing special.
}

static Init_Neopixels(void)
{
    initStrip();
    
    // set strip color red
    fillStrip(0x00, 0x00, 0x00);
    
    // show the strip
    showStrip();
}
